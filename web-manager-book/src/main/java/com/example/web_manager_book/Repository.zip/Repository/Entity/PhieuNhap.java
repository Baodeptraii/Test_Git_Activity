package com.example.web_manager_book.Repository.Entity;

import jakarta.persistence.*;

import java.util.List;


@Entity
@Table(name="PhieuNhap")
public class PhieuNhap {
    @Id
    private int id;
    private String so_phieunhap;
    private String ngayNhap;
    @OneToMany(mappedBy = "phieuNhap")
    private List<ChiTietPhieuNhap> listPhieuNhap;
    @ManyToOne
    @JoinColumn(name="MaNXB")
    private  NhaXuatBan nhaXuatBan;

}
