package com.example.web_manager_book.Repository.Entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

import java.util.List;

@Entity
@Table (name ="TheLoai")
public class TheLoai {
    @Id
    private int id;
    private String maTheLoai;
    private String tenTheLoai;


    @OneToMany (mappedBy = "sach_TheLoai")
    private List<Sach> listSach_TheLoai;//ok
}
