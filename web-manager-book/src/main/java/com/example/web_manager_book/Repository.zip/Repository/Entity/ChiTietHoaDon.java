package com.example.web_manager_book.Repository.Entity;

import jakarta.persistence.*;

@Entity
@Table (name="ChiTietHoaDon")
public class ChiTietHoaDon {
    @Id
    private int id;

    private int soLuongBan;
    private int giaBan;
    @ManyToOne
    @JoinColumn(name="soHD")
    private HoaDon hoaDon;

    @ManyToOne
    @JoinColumn(name="maSach")//ok
    private  Sach maSach_ChiTietHoaDon;
}
