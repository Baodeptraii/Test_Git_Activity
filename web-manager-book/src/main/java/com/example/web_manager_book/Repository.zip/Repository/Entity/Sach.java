package com.example.web_manager_book.Repository.Entity;

import jakarta.persistence.*;

import java.util.List;

@Entity
@Table(name ="Books")
public class Sach {
    @Id
    private int id;
    private String maSach;
    private String tenSach;
    private String soLuongTon;
    @OneToMany(mappedBy = "maSach_ChiTietHoaDon")         //ok
    private List<ChiTietHoaDon> listChiTietHoaDon;//ok

    @ManyToOne
    @JoinColumn (name="MaTheLoai")//oke
    private TheLoai sach_TheLoai;

    @ManyToOne
    @JoinColumn(name="MaTacGia")//oke
    private TacGia sach_TacGia;

    @OneToMany(mappedBy = "chiTietPhieuNhap_Sach")
    private List<ChiTietPhieuNhap> listSach;

    @ManyToOne
    @JoinColumn(name="Sach_MaNXB")
    private NhaXuatBan nhaXuatBan;



}
