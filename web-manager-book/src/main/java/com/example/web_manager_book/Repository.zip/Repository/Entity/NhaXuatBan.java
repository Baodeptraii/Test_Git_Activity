package com.example.web_manager_book.Repository.Entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

import java.util.List;

@Entity
@Table(name="NhaXuatBan")
public class NhaXuatBan {
    @Id
    private int id;

    private String tenNXB;
    private String maNXB;
    private String diaChiNXB;
    private String dienThoai;
    @OneToMany(mappedBy = "nhaXuatBan")
    private List<Sach> listSach;



    @OneToMany(mappedBy = "nhaXuatBan")
    private List<PhieuNhap> listPhieuNhap;
}
