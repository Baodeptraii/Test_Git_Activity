package com.example.web_manager_book.Repository.Entity;

import jakarta.persistence.*;

@Entity
@Table(name="ChiTietPhieuNhap")
public class ChiTietPhieuNhap {
    @Id
    private int id;


    private int soLuongNhap;
    private String giaNhap;

    @ManyToOne
    @JoinColumn(name="MaSach")
    private Sach chiTietPhieuNhap_Sach;

    @ManyToOne
    @JoinColumn(name="so_PhieuNhap")
    private PhieuNhap phieuNhap;
}
